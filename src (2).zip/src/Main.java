import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FestivalService festival = new FestivalService();

        // Adăugare date inițiale (hardcodat)
        Participant p1 = new Participant("Dana", 20, "ana@gmail.com", true,
                new Bilet(150, "VIP"), true, true,"mi a placut");
        festival.adaugaParticipant(p1);



        Merchandise m1 = new Merchandise("Tricou", 70, true, true);
        Merchandise m2 = new Merchandise("Hanorac", 120, false, true);
        festival.adaugaMerchandise(m1);
        festival.adaugaMerchandise(m2);

        // Interfață de meniu
        MeniuFestival meniu = new MeniuFestival(festival);
        Scanner scanner = new Scanner(System.in);
        int optiune;

        do {
            meniu.afiseazaOptiuni();
            try {
                optiune = Integer.parseInt(scanner.nextLine());
                meniu.executaOptiune(optiune);
            } catch (NumberFormatException e) {
                System.out.println("Te rog introdu un număr valid.");
                optiune = -1; // forțăm reluarea meniului
            }
        } while (optiune != 0);

        scanner.close();
    }
}
