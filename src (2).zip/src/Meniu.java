public interface Meniu {
    void afiseazaOptiuni();
    void executaOptiune(int optiune);
}
