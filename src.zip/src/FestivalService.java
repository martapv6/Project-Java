import java.util.*;
import java.time.format.DateTimeFormatter;


public class FestivalService {

    private List<Concert> concerte;
    private List<Participant> participanti;
    private List<Merchandise> merch;
    private TreeSet<Merchandise> merchSortatDupaPret;
    private List<Artist> artisti = new ArrayList<>();
    private List<Dj> djs = new ArrayList<>();
    private List<FoodCourt> standuri = new ArrayList<>();


    public FestivalService() {
        concerte = new ArrayList<>();
        participanti = new ArrayList<>();
        merch = new ArrayList<>();
        merchSortatDupaPret = new TreeSet<>(Comparator.comparingDouble(Merchandise::getPret));
    }

    // 1
    public void adaugaParticipant(Participant p)
    {
        participanti.add(p);
    }

    // 2
    public void adaugaConcert(Concert c)
    {
        concerte.add(c);
    }

    // 3
    public void adaugaMerchandise(Merchandise m)
    {
        merch.add(m);
        merchSortatDupaPret.add(m);
    }

    // 4
    public void afiseazaMerchSortat()
    {
        for (Merchandise m : merchSortatDupaPret) {
            System.out.println(m.getProdus() + " - " + m.getPret() + " lei");
        }
    }

    // 5
    public Participant getParticipantCuCelMaiScumpBilet() {
        if (participanti.isEmpty()) return null;
        Participant max = participanti.get(0);
        for (Participant p : participanti) {
            if (p.getBilet().getPret() > max.getBilet().getPret()) {
                max = p;
            }
        }
        return max;
    }

    // 6
    public double getVenitTotal() {
        double suma = 0;
        for (Participant p : participanti)
        {
            suma += p.getBilet().getPret();

        }
        for (Merchandise m : merch) {
            if (m.getVandut()==true)
            {
                suma += m.getPret();
            }
        }
        return suma;
    }

    // 7
    public void afiseazaConcerturi()
    {
        for (Concert c : concerte)
        {
            System.out.println(c.getNume() + " - " + c.getData());
        }
    }

    // 8
    public void afiseazaParticipanti()
    {
        for (Participant p : participanti)
        {
            System.out.println(p.getNume());
        }
    }

    // 9
    public int numarTotalParticipanti() {
        return participanti.size();
    }

    // 10
    public void afiseazaMerchandisePestePret(double pretMinim)
    {
        for (Merchandise m : merch) {
            if (m.getPret() >= pretMinim) {
                System.out.println(m.getProdus() + " - " + m.getPret());
            }
        }
    }
    public void sorteazaParticipantiDupaPretBilet()
    {
        participanti.sort((p1, p2) -> Integer.compare(p2.getBilet().getPret(), p1.getBilet().getPret()));
        System.out.println("=== Participanți sortați după prețul biletului (descrescător): ===");
        for (Participant p : participanti) {
            System.out.println(p.getNume() + " - " + p.getBilet().getPret() + " lei");
        }
    }

    public void afiseazaParticipantiCuPreferinte() {
        System.out.println("=== Participanți cu preferințe merch/food ===");
        for (Participant p : participanti) {
            if (p.isPreferaMerch() || p.isPreferaFood()) {
                System.out.println(p.getNume() + " | Merch: " + p.isPreferaMerch() + " | Food: " + p.isPreferaFood());
            }
        }
    }


    public void cautaParticipant(String nume) {
        System.out.println("=== Căutare participant: " + nume + " ===");
        boolean gasit = false;
        for (Participant p : participanti) {
            if (p.getNume().toLowerCase().contains(nume.toLowerCase())) {
                System.out.println("Găsit: " + p.getNume() + " - " + p.getEmail());
                gasit = true;
            }
        }
        if (!gasit) {
            System.out.println("Niciun participant găsit cu acest nume.");
        }
    }

    public void afiseazaRaportFinal() {
        System.out.println("🎉 Raport Festival:");
        System.out.println("- Participanți: " + participanti.size());
        System.out.println("- Venit total: " + getVenitTotal() + " lei");
        System.out.println("- Concerte: " + concerte.size());
        System.out.println("- Merchandise total: " + merch.size());
        System.out.println("- Merchandise vândut: " + merch.stream().filter(Merchandise::getVandut).count());
        System.out.println("- Participanți VIP: " +
                participanti.stream().filter(p -> p.getBilet().getTip().equalsIgnoreCase("VIP")).count());
    }

    public List<Concert> getConcerte() {
        return concerte;
    }

    public List<Merchandise> getMerchandise() {
        return merch;
    }
    public void statisticaFeedback() {
        System.out.println("\n=== Feedback participanți ===");
        Map<String, Integer> feedbackMap = new HashMap<>();

        for (Participant p : participanti) {
            String fb = p.getFeedback() != null ? p.getFeedback().toLowerCase() : "neprecizat";
            feedbackMap.put(fb, feedbackMap.getOrDefault(fb, 0) + 1);
        }

        for (String tip : feedbackMap.keySet()) {
            System.out.println("- " + tip + ": " + feedbackMap.get(tip) + " participanți");
        }
    }

    public void afiseazaGraficVenituri() {
        System.out.println("\n📊 Grafic venituri ");

        Map<String, Double> venituriPeZi = new TreeMap<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (Concert c : concerte) {
            String data = c.getData(); // presupunem format "yyyy-MM-dd"
            venituriPeZi.putIfAbsent(data, 0.0);

            double venitZi = 0.0;

            // adunăm banii din bilete
            for (Participant p : participanti) {
                venitZi += p.getBilet().getPret();
            }

            // adunăm banii din merch vândut
            for (Merchandise m : merch) {
                if (m.getVandut()) {
                    venitZi += m.getPret();
                }
            }

            venituriPeZi.put(data, venituriPeZi.get(data) + venitZi);
        }

        // Calculează venit total (pentru scalare grafic)
        double venitTotal = venituriPeZi.values().stream().mapToDouble(Double::doubleValue).sum();

        System.out.println("\n=== Grafic ASCII pe baza concertelor ===");
        for (Map.Entry<String, Double> entry : venituriPeZi.entrySet()) {
            String data = entry.getKey();
            double venit = entry.getValue();
            int bar = (int) (venit / venitTotal * 50);

            System.out.printf("%s: %s %.2f lei\n", data, "█".repeat(bar), venit);
        }
    }


    public void adaugaArtist(Artist artist) {
        artisti.add(artist);
    }

    public void adaugaDj(Dj dj) {
        djs.add(dj);
    }

    public void adaugaFoodCourt(FoodCourt fc) {
        standuri.add(fc);
    }


}
